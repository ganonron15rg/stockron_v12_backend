# =============================================================
# 🤖 Stockron Master Agent v13.2
# Rotates between multiple free agents to avoid rate limits
# =============================================================
import random, asyncio
from src.providers.yahoo_agent import YahooAgent
from src.providers.alpha_agent import AlphaAgent
from src.providers.news_master_agent import NewsMasterAgent

class StockronMasterAgent:
    def __init__(self):
        self.finance_agents = [YahooAgent(), AlphaAgent()]
        self.news_master = NewsMasterAgent()
        self.index_f = 0

    async def get_financial_data(self, ticker: str):
        for i in range(len(self.finance_agents)):
            agent = self.finance_agents[(self.index_f + i) % len(self.finance_agents)]
            try:
                data = await agent.fetch(ticker)
                self.index_f = (self.index_f + 1) % len(self.finance_agents)
                return data
            except Exception as e:
                print(f"⚠️ {agent.__class__.__name__} failed: {e}")
        raise RuntimeError("No financial agents available")

    async def get_news(self, ticker: str):
        return await self.news_master.get_news(ticker)
