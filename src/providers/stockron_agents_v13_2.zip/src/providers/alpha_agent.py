# =============================================================
# 🧮 Alpha Agent - Backup free financial data
# =============================================================
import httpx
from datetime import datetime

class AlphaAgent:
    async def fetch(self, ticker: str):
        url = f"https://www.alphavantage.co/query?function=OVERVIEW&symbol={ticker}&apikey=demo"
        r = httpx.get(url, timeout=6.0)
        data = r.json()
        return {
            "source": "Alpha Vantage",
            "ticker": ticker,
            "price": data.get("50DayMovingAverage"),
            "pe_ratio": data.get("PERatio"),
            "market_cap": data.get("MarketCapitalization"),
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
