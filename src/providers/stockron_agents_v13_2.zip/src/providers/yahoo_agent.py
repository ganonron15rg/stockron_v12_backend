# =============================================================
# 📈 Yahoo Finance Agent (Free, primary data source)
# =============================================================
import yfinance as yf
from datetime import datetime

class YahooAgent:
    async def fetch(self, ticker: str):
        info = yf.Ticker(ticker).info
        hist = yf.Ticker(ticker).history(period="6mo", interval="1d")
        return {
            "source": "Yahoo Finance",
            "ticker": ticker,
            "price": info.get("currentPrice"),
            "pe_ratio": info.get("trailingPE"),
            "market_cap": info.get("marketCap"),
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
